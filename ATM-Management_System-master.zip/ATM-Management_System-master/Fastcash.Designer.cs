﻿namespace WindowsFormsApp18
{
    partial class btn2000
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(btn2000));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClose = new Bunifu.Framework.UI.BunifuThinButton2();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn10000 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnTransactions = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn500 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn5000 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn1000 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn100 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnBack = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblBal = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(804, 86);
            this.panel1.TabIndex = 15;
            // 
            // btnClose
            // 
            this.btnClose.ActiveBorderThickness = 1;
            this.btnClose.ActiveCornerRadius = 20;
            this.btnClose.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnClose.ActiveForecolor = System.Drawing.Color.White;
            this.btnClose.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClose.BackgroundImage")));
            this.btnClose.ButtonText = "X";
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnClose.IdleBorderThickness = 1;
            this.btnClose.IdleCornerRadius = 20;
            this.btnClose.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnClose.IdleForecolor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnClose.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnClose.Location = new System.Drawing.Point(729, 0);
            this.btnClose.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(51, 53);
            this.btnClose.TabIndex = 55;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(145, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(500, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "ATM Management System";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(317, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 36);
            this.label3.TabIndex = 45;
            this.label3.Text = "Fast Cash";
            // 
            // btn10000
            // 
            this.btn10000.ActiveBorderThickness = 1;
            this.btn10000.ActiveCornerRadius = 20;
            this.btn10000.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btn10000.ActiveForecolor = System.Drawing.Color.White;
            this.btn10000.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btn10000.BackColor = System.Drawing.SystemColors.Control;
            this.btn10000.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn10000.BackgroundImage")));
            this.btn10000.ButtonText = "Rs.10000";
            this.btn10000.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn10000.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn10000.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn10000.IdleBorderThickness = 1;
            this.btn10000.IdleCornerRadius = 20;
            this.btn10000.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn10000.IdleForecolor = System.Drawing.Color.White;
            this.btn10000.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn10000.Location = new System.Drawing.Point(477, 354);
            this.btn10000.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn10000.Name = "btn10000";
            this.btn10000.Size = new System.Drawing.Size(189, 47);
            this.btn10000.TabIndex = 51;
            this.btn10000.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn10000.Click += new System.EventHandler(this.btn10000_Click);
            // 
            // btnTransactions
            // 
            this.btnTransactions.ActiveBorderThickness = 1;
            this.btnTransactions.ActiveCornerRadius = 20;
            this.btnTransactions.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnTransactions.ActiveForecolor = System.Drawing.Color.White;
            this.btnTransactions.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnTransactions.BackColor = System.Drawing.SystemColors.Control;
            this.btnTransactions.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTransactions.BackgroundImage")));
            this.btnTransactions.ButtonText = "Rs.2000";
            this.btnTransactions.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransactions.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransactions.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnTransactions.IdleBorderThickness = 1;
            this.btnTransactions.IdleCornerRadius = 20;
            this.btnTransactions.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTransactions.IdleForecolor = System.Drawing.Color.White;
            this.btnTransactions.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTransactions.Location = new System.Drawing.Point(477, 269);
            this.btnTransactions.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTransactions.Name = "btnTransactions";
            this.btnTransactions.Size = new System.Drawing.Size(189, 47);
            this.btnTransactions.TabIndex = 50;
            this.btnTransactions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnTransactions.Click += new System.EventHandler(this.btnTransactions_Click);
            // 
            // btn500
            // 
            this.btn500.ActiveBorderThickness = 1;
            this.btn500.ActiveCornerRadius = 20;
            this.btn500.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btn500.ActiveForecolor = System.Drawing.Color.White;
            this.btn500.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btn500.BackColor = System.Drawing.SystemColors.Control;
            this.btn500.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn500.BackgroundImage")));
            this.btn500.ButtonText = "Rs.500";
            this.btn500.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn500.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn500.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn500.IdleBorderThickness = 1;
            this.btn500.IdleCornerRadius = 20;
            this.btn500.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn500.IdleForecolor = System.Drawing.Color.White;
            this.btn500.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn500.Location = new System.Drawing.Point(477, 190);
            this.btn500.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn500.Name = "btn500";
            this.btn500.Size = new System.Drawing.Size(189, 47);
            this.btn500.TabIndex = 49;
            this.btn500.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn500.Click += new System.EventHandler(this.btn500_Click);
            // 
            // btn5000
            // 
            this.btn5000.ActiveBorderThickness = 1;
            this.btn5000.ActiveCornerRadius = 20;
            this.btn5000.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btn5000.ActiveForecolor = System.Drawing.Color.White;
            this.btn5000.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btn5000.BackColor = System.Drawing.SystemColors.Control;
            this.btn5000.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn5000.BackgroundImage")));
            this.btn5000.ButtonText = "Rs.5000";
            this.btn5000.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn5000.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5000.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn5000.IdleBorderThickness = 1;
            this.btn5000.IdleCornerRadius = 20;
            this.btn5000.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn5000.IdleForecolor = System.Drawing.Color.White;
            this.btn5000.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn5000.Location = new System.Drawing.Point(108, 354);
            this.btn5000.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn5000.Name = "btn5000";
            this.btn5000.Size = new System.Drawing.Size(189, 47);
            this.btn5000.TabIndex = 48;
            this.btn5000.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn5000.Click += new System.EventHandler(this.btn5000_Click);
            // 
            // btn1000
            // 
            this.btn1000.ActiveBorderThickness = 1;
            this.btn1000.ActiveCornerRadius = 20;
            this.btn1000.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btn1000.ActiveForecolor = System.Drawing.Color.White;
            this.btn1000.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btn1000.BackColor = System.Drawing.SystemColors.Control;
            this.btn1000.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn1000.BackgroundImage")));
            this.btn1000.ButtonText = "Rs.1000";
            this.btn1000.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn1000.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1000.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn1000.IdleBorderThickness = 1;
            this.btn1000.IdleCornerRadius = 20;
            this.btn1000.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn1000.IdleForecolor = System.Drawing.Color.White;
            this.btn1000.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn1000.Location = new System.Drawing.Point(108, 269);
            this.btn1000.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn1000.Name = "btn1000";
            this.btn1000.Size = new System.Drawing.Size(189, 47);
            this.btn1000.TabIndex = 47;
            this.btn1000.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn1000.Click += new System.EventHandler(this.btn1000_Click);
            // 
            // btn100
            // 
            this.btn100.ActiveBorderThickness = 1;
            this.btn100.ActiveCornerRadius = 20;
            this.btn100.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btn100.ActiveForecolor = System.Drawing.Color.White;
            this.btn100.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btn100.BackColor = System.Drawing.SystemColors.Control;
            this.btn100.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn100.BackgroundImage")));
            this.btn100.ButtonText = "Rs.100";
            this.btn100.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn100.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn100.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn100.IdleBorderThickness = 1;
            this.btn100.IdleCornerRadius = 20;
            this.btn100.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn100.IdleForecolor = System.Drawing.Color.White;
            this.btn100.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn100.Location = new System.Drawing.Point(108, 190);
            this.btn100.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn100.Name = "btn100";
            this.btn100.Size = new System.Drawing.Size(189, 47);
            this.btn100.TabIndex = 46;
            this.btn100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn100.Click += new System.EventHandler(this.btn100_Click);
            // 
            // btnBack
            // 
            this.btnBack.ActiveBorderThickness = 1;
            this.btnBack.ActiveCornerRadius = 20;
            this.btnBack.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnBack.ActiveForecolor = System.Drawing.Color.White;
            this.btnBack.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnBack.BackColor = System.Drawing.SystemColors.Control;
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.ButtonText = "Back";
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnBack.IdleBorderThickness = 1;
            this.btnBack.IdleCornerRadius = 20;
            this.btnBack.IdleFillColor = System.Drawing.Color.White;
            this.btnBack.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnBack.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnBack.Location = new System.Drawing.Point(309, 423);
            this.btnBack.Margin = new System.Windows.Forms.Padding(5);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(166, 43);
            this.btnBack.TabIndex = 52;
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Location = new System.Drawing.Point(-1, 473);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(784, 11);
            this.panel2.TabIndex = 53;
            // 
            // lblBal
            // 
            this.lblBal.AutoSize = true;
            this.lblBal.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblBal.Location = new System.Drawing.Point(465, 143);
            this.lblBal.Name = "lblBal";
            this.lblBal.Size = new System.Drawing.Size(104, 28);
            this.lblBal.TabIndex = 55;
            this.lblBal.Text = "Amount";
            this.lblBal.Click += new System.EventHandler(this.lblBal_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(190, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(233, 28);
            this.label4.TabIndex = 54;
            this.label4.Text = "Available Balance :";
            // 
            // btn2000
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 481);
            this.Controls.Add(this.lblBal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btn10000);
            this.Controls.Add(this.btnTransactions);
            this.Controls.Add(this.btn500);
            this.Controls.Add(this.btn5000);
            this.Controls.Add(this.btn1000);
            this.Controls.Add(this.btn100);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "btn2000";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fastcash";
            this.Load += new System.EventHandler(this.Fastcash_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuThinButton2 btn10000;
        private Bunifu.Framework.UI.BunifuThinButton2 btnTransactions;
        private Bunifu.Framework.UI.BunifuThinButton2 btn500;
        private Bunifu.Framework.UI.BunifuThinButton2 btn5000;
        private Bunifu.Framework.UI.BunifuThinButton2 btn1000;
        private Bunifu.Framework.UI.BunifuThinButton2 btn100;
        private Bunifu.Framework.UI.BunifuThinButton2 btnBack;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuThinButton2 btnClose;
        private System.Windows.Forms.Label lblBal;
        private System.Windows.Forms.Label label4;
    }
}