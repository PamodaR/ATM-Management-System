﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp18
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            
        }
        public static String AcNO;
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-F81GNF66;Initial Catalog=ATMdb;Integrated Security=True");
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtAcNo.Text == "" || txtPIN.Text == "")
            {
                MessageBox.Show("Invalid Account Number or PIN", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select count(*) from tblAccount2 where AccNum= '" + txtAcNo.Text + "' and PIN = " + txtPIN.Text + "", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                AcNO =txtAcNo.Text;
                Home home = new Home();
                home.Show();
                this.Hide();
                con.Close();

            }
            else
            {
                MessageBox.Show("Invalid Account Number or PIN", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            con.Close();

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            Account acc = new Account();
            acc.Show();
            this.Hide();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void txtPIN_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
